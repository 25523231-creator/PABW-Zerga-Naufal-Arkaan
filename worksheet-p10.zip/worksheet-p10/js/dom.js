
export function inisialisasiFilter(dataOlahraga) {
  const barisFilter = document.querySelector("#filter");

  if (!barisFilter) {
    console.error("Elemen #filter tidak ditemukan.");
    return;
  }

  barisFilter.addEventListener("click", (event) => {
    const tombol = event.target.closest("button[data-kategori]");

    // Abaikan klik yang bukan tombol filter
    if (!tombol || !barisFilter.contains(tombol)) return;

    const kategori = tombol.dataset.kategori;

    // Pilih data berdasarkan kategori tombol
    const dataTerpilih = dataOlahraga.filter((olahraga) => {
      return (
        kategori === "semua" ||
        olahraga.kategori === kategori
      );
    });

    // Tampilkan atau sembunyikan baris tabel yang sesuai
    dataOlahraga.forEach((olahraga) => {
      olahraga.elemen.hidden = !dataTerpilih.includes(olahraga);
    });

    // Tandai tombol yang sedang aktif
    barisFilter.querySelectorAll("button").forEach((item) => {
      item.classList.toggle("aktif", item === tombol);
    });
  });
}
